import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:rateme/login.dart';
import 'package:http/http.dart' as http;
import 'BottomNav.dart';
import 'cafe_response.dart';

void main() {
  runApp(const Home());
}

class Home extends StatelessWidget {
  const Home({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'RateMe',
      theme: ThemeData(
        primarySwatch: Colors.brown,
      ),
      home: const HomePage(title: 'RateMe'),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key, required this.title});
  final String title;

  @override
  State<HomePage> createState() => _HomePageState();
}

Future<List<cafe_response>> fetchCafe() async{
  final res = await http.get(Uri.parse('http://30.10.10.15:8000/api/Cafe'));
  if (res.statusCode == 200){
    var data = jsonDecode(res.body);
    var parsed = data['list'].cast<Map<String, dynamic>>();
    return parsed.map<cafe_response>((json) => cafe_response.fromJson(json)).toList();
  }else {
    throw Exception('Failed');
  }
}

class _HomePageState extends State<HomePage> {
  late Future<List<cafe_response>> cafe;

  @override
  void initState(){
    super.initState();
    cafe = fetchCafe();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(widget.title),
          backgroundColor: Color(0xff7c6354),
          leading: Container(
            padding: EdgeInsets.only(top: 15,bottom: 15,left: 15),
            child: Image.asset('assets/whiteLogo.png'),
          ),
          actions: [
            PopupMenuButton<MenuItem>(
              onSelected: (item) => onSelected(context,item),
              itemBuilder: (context) => [
                ...MenuItems.itemsFirst.map(buildItem).toList(),
              ],
            ),
          ],

        ),
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            SizedBox(height: 18),
            Padding(
              padding: const EdgeInsets.all(15),
              child: Container(
                height: 60,
                width: double.infinity,
                decoration: BoxDecoration(
                    color: Color(0xFFF5F5F7),
                    borderRadius: BorderRadius.circular(30)),
                child: TextField(
                  cursorHeight: 20,
                  autofocus: false,
                  decoration: InputDecoration(
                    hintText: "Cari kafe atau restaurant",
                    prefixIcon: Icon(Icons.search),
                    border: OutlineInputBorder(
                        borderSide:
                        BorderSide(color: Colors.grey, width: 2),
                        borderRadius: BorderRadius.circular(30)
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(height: 12),
            Row(
              children: [
                Container(
                  padding: EdgeInsets.only(left: 15),
                  child: Text('Rekomendasi', style: GoogleFonts.montserrat(fontSize: 24, fontWeight: FontWeight.bold)),
                )
              ],
            ),
            SizedBox(height: 16),
            Expanded(
                child:FutureBuilder<List<cafe_response>>(
                    future: cafe,
                    builder: (context, snapshot){
                      if(snapshot.hasData){
                        if(snapshot.data!.isEmpty){
                          return const Center(
                            child: Text("gada"),
                          );
                        }
                        return ListView.separated(
                          padding: const EdgeInsets.all(8),
                          itemCount: snapshot.data!.length,
                          itemBuilder: (context, index) {
                            return CoffeShop(
                              imagePath: snapshot.data![index].image,
                              nameShop: snapshot.data![index].title,
                              addr: snapshot.data![index].description,
                              rating: snapshot.data![index].rating,
                            );
                          },
                          separatorBuilder: (BuildContext context, int index){
                            return Divider(thickness: 0.5,
                              indent: 250,
                              endIndent: 250,
                            );
                          },
                        );
                      }else{
                        return const Center(
                          child: CircularProgressIndicator(),
                        );
                      }
                    }
                )
            )
          ],
        )

            )
    );
  }
  PopupMenuItem<MenuItem>buildItem(MenuItem item) => PopupMenuItem<MenuItem>(
      value: item,
      child: Row(
        children: [
          Icon(item.icon,color: Colors.black, size:20),
          const SizedBox(width: 12),
          Text(item.text)
        ],
      )
  );

  void onSelected(BuildContext context, MenuItem item) {
    switch(item){
      case MenuItems.itemSignOut:
        Navigator.of(context, rootNavigator: true).pushAndRemoveUntil(
          MaterialPageRoute(
            builder: (BuildContext context) {
              return LoginApp();
            },
          ),
              (_) => false,
        );
    }
  }
}

class CoffeShop extends StatelessWidget {
  final String imagePath;
  final String nameShop;
  final String addr;
  final double rating;
  const CoffeShop(
      {Key? key,
        required this.imagePath,
        required this.nameShop,
        required this.addr,
        required this.rating,})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
        width: double.infinity,
        height: 264,
        child: Stack(
          children: [
            Card(
              child: new InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => DetailScreen(todo : Todo(imagePath,nameShop,addr,rating))),
                  );
                },
                child: Column(
                  children: [
                    SizedBox(
                        width: double.infinity,
                        height: 150,
                        child: Image.network(imagePath, fit: BoxFit.cover)),
                    Positioned(
                        bottom: 0,
                        left: 10,
                        child: SizedBox(
                          height: 80,
                          child: Padding(
                            padding: const EdgeInsets.only(left: 10, right: 10, top: 15),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Text(nameShop,
                                        style: GoogleFonts.montserrat(
                                            fontSize: 17, fontWeight: FontWeight.bold)),
                                    SizedBox(
                                      width: 8,
                                    ),
                                    Icon(Icons.star, color: Colors.amber),
                                    SizedBox(
                                      width: 5,
                                    ),
                                    Text(rating.toString(),
                                        style: GoogleFonts.montserrat(fontSize: 12)),
                                    SizedBox(
                                      width: 20,
                                    ),
                                  ],
                                ),
                                SizedBox(height: 10),
                                Text(addr,
                                    style: GoogleFonts.montserrat(
                                        fontSize: 12)),
                              ],
                            ),
                          ),
                        )),
                  ],
                ),
              ),
              clipBehavior: Clip.antiAliasWithSaveLayer,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
              elevation: 10,
            ),
          ],
        ));
  }
}
class Todo {
  final String imagePath;
  final String nameShop;
  final String addr;
  final double rating;
  const Todo(
         this.imagePath,
         this.nameShop,
         this.addr,
         this.rating);
}

class MenuItem{
  final String text;
  final IconData icon;

  const MenuItem({
    required this.text,
    required this.icon,
  });
}

class MenuItems{
  static const List<MenuItem> itemsFirst = [
    itemSignOut,
  ];

  static const itemSignOut = MenuItem(text: 'Sign Out', icon: Icons.logout);
}

class DetailScreen extends StatelessWidget {
  // In the constructor, require a Todo.
  const DetailScreen({super.key, required this.todo});

  // Declare a field that holds the Todo.
  final Todo todo;

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double widht = MediaQuery.of(context).size.width;
    return Scaffold(
      body: SingleChildScrollView(
        child: SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Tumpukan foto dan Container Nama Toko
                Stack(
                  alignment: Alignment.bottomCenter,
                  children: [
                    Container(
                      height: height * 0.3,
                      width: double.infinity,
                      decoration: BoxDecoration(
                          image: DecorationImage(
                              fit: BoxFit.cover,
                              image: NetworkImage(todo.imagePath))),
                    ),
                    Positioned(
                      top: 16,
                      left: 16,
                      child: InkWell(
                        child: Container(
                          child: Icon(
                            Icons.arrow_back,
                            color: Colors.white,
                          ),
                          padding: EdgeInsets.all(8),
                          decoration: BoxDecoration(
                              color: Colors.grey,
                              borderRadius: BorderRadius.all(Radius.circular(20))),
                        ),
                        onTap: () {
                          // Navigator.push(
                          //   context,
                          //   MaterialPageRoute(builder: (context) => navbar()),
                          // );
                          Navigator.of(context, rootNavigator: true).pushAndRemoveUntil(
                            MaterialPageRoute(
                              builder: (BuildContext context) {
                                return navbar();
                              },
                            ),
                                (_) => false,
                          );
                        },
                      ),
                    ),
                    Container(
                        child: Padding(
                          padding: const EdgeInsets.only(left: 16.0, top: 16.0, right: 16.0),
                          child: Column(
                            children: [
                              Row(
                                children: [
                                  Text(
                                    todo.nameShop,
                                    style: GoogleFonts.montserrat(
                                        fontSize: 18, fontWeight: FontWeight.bold),
                                  ),
                                  SizedBox(width: 8),
                                  Icon(
                                    Icons.star,
                                    color: Colors.amber,
                                  ),
                                  SizedBox(
                                    width: 5,
                                  ),
                                  Text(todo.rating.toString(),
                                      style: GoogleFonts.montserrat(fontSize: 12))
                                ],
                              ),
                            ],
                          )

                        ),
                        height: height * .07,
                        width: double.infinity,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(20),
                                topRight: Radius.circular(20))))
                  ],
                ),
                // Row rating dan jam buka
                Padding(
                  padding: const EdgeInsets.only(left: 16.0, right: 16.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                        Text(todo.addr.toString(),
                            style: GoogleFonts.montserrat(fontSize: 12)),
                        SizedBox(height: 32),
                        Row(children: [
                          Text('Menu', style: GoogleFonts.montserrat(fontSize: 18, fontWeight: FontWeight.bold))
                        ],
                      )
                    ],
                  ),
                ),

                // Alamat
                TitleDetail(
                    title: todo.nameShop,
                    detail:todo.addr),

                // Deskripsi

                // Title Ulasan / Comment

                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(
                    "Comment",
                    style: GoogleFonts.montserrat(
                        fontSize: 12, fontWeight: FontWeight.bold),
                  ),
                ),

                // Widget Ulasan / Comment
                Comment(), Comment(), Comment(), Comment()
              ],
            )),
      ),
    );
  }
}

class Comment extends StatelessWidget {
  const Comment({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Row(
            children: [
              Image.network(
                "https://oliver-andersen.se/wp-content/uploads/2018/03/cropped-Profile-Picture-Round-Color.png",
                width: 40,
              ),
              SizedBox(
                width: 10,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Albert Von Martin",
                      style: GoogleFonts.montserrat(fontSize: 12,fontWeight: FontWeight.w700)),
                ],
              )
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Text(
              style: GoogleFonts.montserrat(fontSize: 12),
              " is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, ")
        ],
      ),
    );
  }
}

class TitleDetail extends StatelessWidget {
  final String title;
  final String detail;
  const TitleDetail({Key? key, required this.title, required this.detail})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: GoogleFonts.montserrat(
                fontSize: 12, fontWeight: FontWeight.bold),
          ),
          SizedBox(
            height: 10,
          ),
          Text(detail, style: GoogleFonts.montserrat(fontSize: 12))
        ],
      ),
    );
  }
}